
/* File for 'narrow_bridge' task implementation.  
   S_PbS_TU, IBKS_, 2017 */

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/thread.h"
#include "threads/synch.h"
#include "narrow-bridge.h"

// Called before test. Can initialize some synchronization objects.
// unsigned int car_left = 0, car_right = 0;
unsigned int emer_car_right = 0, emer_car_left = 0;
unsigned int wait_car_left = 0, wait_car_right = 0;
unsigned int wait_emer_left = 0, wait_emer_right = 0;
unsigned int on_bridge = 0;
unsigned int switcher = 0;
unsigned int wait_left = 0;
unsigned int wait_right = 0;
int slept = 0;
enum current_direction 
{
	left = 0,
	right = 1,
	none = 2
};
enum current_direction bridge_dir = 2;
struct semaphore S_car_left, S_car_right, S_emer_left, S_emer_right;

void narrow_bridge_init(void)
{
	sema_init(&S_car_left, 0);
	sema_init(&S_car_right, 0);
	sema_init(&S_emer_left, 0);
	sema_init(&S_emer_right, 0);
}
void alloc_waiters(enum car_priority prio, enum car_direction dir)
{
	if(prio == 1)
	{
		if (dir == left)
		{
			wait_emer_left++;
			sema_down(&S_emer_left);
		}
		else
		{
			wait_emer_right++;
			sema_down(&S_emer_right);
		}
	}
	else
	{
		if(dir == left)
		{
			wait_car_left++;
			sema_down(&S_car_left);
		}
		else
		{
			wait_car_right++;
			sema_down(&S_car_right);
		}
	}
}
void free_waiters(enum car_priority prio, enum car_direction dir)
{
	if(prio == 1) dir == left ? sema_up(&S_emer_left) : sema_up(&S_emer_right);
	else dir == left ? sema_up(&S_car_left) : sema_up(&S_car_right);
}
int dir_op(enum car_direction dir)
{
	return dir == 1 ? 0 : 1;
}
void arrive_bridge(enum car_priority prio, enum car_direction dir)
{
	if(prio == 1)
	{
		if(on_bridge >= 2 || bridge_dir == dir_op(dir)) alloc_waiters(prio, dir);
		on_bridge++;
		bridge_dir = dir;
	}
	else
	{
		int wait_emer = dir == left ? wait_emer_left : wait_emer_right;
		if(on_bridge >= 2 || bridge_dir == dir_op(dir) || wait_emer > 0) alloc_waiters(prio, dir);
		on_bridge++;
		bridge_dir = dir;
	}
	// printf("A on_bridge: %d, crossed: %d, dir: %d\n", on_bridge, switcher, bridge_dir);
}

void exit_bridge(enum car_priority prio, enum car_direction dir)
{
	on_bridge--;	
	switcher++;
	// if(on_bridge < 2)
	// {
	// 	if(bridge_dir == left)
	// 	{
	// 		if(wait_emer_left > 0 && wait_right == 0) free_waiters(1, left);
	// 		else if(wait_car_left > 0 && wait_right == 0) free_waiters(0, left);
	// 	}
	// 	else if(bridge_dir == right)
	// 	{
	// 		if(wait_emer_right > 0 && wait_left == 0) free_waiters(1, right);
	// 		else if(wait_car_right > 0 && wait_left == 0) free_waiters(0, right);
	// 	}
	// }
	wait_left = wait_car_left + wait_emer_left;
	wait_right = wait_car_right + wait_emer_right;
	printf("On: %d, dir: %d sw: %d (EL %d ER %d CL %d CR %d)\n", on_bridge, bridge_dir, switcher, wait_emer_left, wait_emer_right, wait_car_left, wait_car_right);
	if(on_bridge == 0)
	{
		if(switcher >= 3 || (wait_car_left > 0 && wait_car_right > 0))
		{
			switcher = 0;
			bridge_dir = dir_op(bridge_dir);
			if(bridge_dir == left && wait_emer_left > 0)
			{
				wait_emer_left--;
				free_waiters(1, 0);
			}
			else if(bridge_dir == right && wait_emer_right > 0)
			{
				wait_emer_right--;
				free_waiters(1, 1);
			}
			else if(bridge_dir == left && wait_car_left > 0)
			{
				wait_car_left--;
				free_waiters(0, 0);
			}
			else if(bridge_dir == right && wait_car_right > 0)
			{
				wait_car_right--;
				free_waiters(0, 1);
			}
		}
		
	}
	// printf("E on_bridge: %d, crossed: %d, dir: %d\n", on_bridge, switcher, bridge_dir);
}
